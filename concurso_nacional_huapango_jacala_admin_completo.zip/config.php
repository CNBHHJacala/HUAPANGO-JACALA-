<?php
declare(strict_types=1);

/*
 * CONFIGURACIÓN PRINCIPAL
 * Copia este archivo como respaldo, pero NO publiques tus credenciales.
 */

const DB_HOST = 'localhost';
const DB_NAME = 'concurso_huapango';
const DB_USER = 'TU_USUARIO_MYSQL';
const DB_PASS = 'TU_PASSWORD_MYSQL';

const SITE_NAME = 'Concurso Nacional de Huapango';
const SITE_URL = 'https://TU-DOMINIO.com';

/*
 * Precio de inscripción por pareja.
 * CAMBIA ESTE VALOR antes de publicar.
 */
const INSCRIPTION_PRICE = 250.00;

/*
 * Mercado Pago
 * Usa primero credenciales TEST.
 */
const MP_ACCESS_TOKEN = 'TU_ACCESS_TOKEN';
const MP_WEBHOOK_SECRET = 'TU_WEBHOOK_SECRET';

/*
 * Credenciales de administración.
 * CAMBIA ambas antes de publicar.
 */
const ADMIN_USER = 'admin';
const ADMIN_PASSWORD = 'CAMBIA-ESTA-CONTRASENA';

const CATEGORIES = [
    'Pequeños Huapangueros',
    'Infantil',
    'Juvenil',
    'Adulto'
];

const STYLES = [
    'Queretano',
    'Tamaulipeco',
    'Veracruzano',
    'Hidalguense',
    'Potosino',
    'Poblano'
];

function db(): PDO {
    static $pdo = null;

    if ($pdo instanceof PDO) {
        return $pdo;
    }

    $pdo = new PDO(
        'mysql:host=' . DB_HOST . ';dbname=' . DB_NAME . ';charset=utf8mb4',
        DB_USER,
        DB_PASS,
        [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES => false
        ]
    );

    return $pdo;
}

function e(?string $value): string {
    return htmlspecialchars($value ?? '', ENT_QUOTES, 'UTF-8');
}

function siteUrl(string $path = ''): string {
    return rtrim(SITE_URL, '/') . '/' . ltrim($path, '/');
}

function generateFolio(int $numero): string {
    return 'HJP-' . date('Y') . '-' . str_pad((string)$numero, 4, '0', STR_PAD_LEFT);
}
