<footer class="footer">
  <p>Concurso Nacional de Huapango · Jacala de Ledezma · Sistema de registro en línea</p>
</footer>
</body>
</html>
